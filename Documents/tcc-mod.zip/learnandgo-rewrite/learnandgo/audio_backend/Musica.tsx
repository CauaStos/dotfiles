import { getSongs } from "@/database_api/fetch";
import { AVPlaybackStatus, Audio } from "expo-av";
import { Sound } from "expo-av/build/Audio";
import { usePathname } from "expo-router";
import { useEffect, useState } from "react";
import { TouchableOpacity } from "react-native";
import { Text } from "react-native";

export default function Musica() {
  const [songs, setSongs] = useState<any>(null);
  const [isAudioSet, setIsAudioSet] = useState(false);
  const [currentSong, setCurrentSong] = useState(0);
  const [sound, setSound] = useState<Sound>();
  const [status, setStatus] = useState<AVPlaybackStatus>();
  const [isCurrentSongFirst, setIsCurrentSongFirst] = useState(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.1);
  const pathname = usePathname();

  // Fetch songs from DB
  useEffect(() => {
    const fetchSongs = async () => {
      const data = await getSongs();
      setSongs(data);
    };
    fetchSongs();
  }, []);

  // Setup audio when songs are fetched
  useEffect(() => {
    if (songs && !isAudioSet) {
      const loadAudio = async () => {
        console.log("Loading Sound");
        const { sound, status } = await Audio.Sound.createAsync({
          uri: songs[currentSong].tb08_sound_url,
        });
        sound.setIsLoopingAsync(true);
        setSound(sound);

        // Play the sound immediately after loading
        await sound.playAsync();
        setIsPlaying(true);
      };
      loadAudio();
      setIsAudioSet(true);
    }
  }, [songs, currentSong, isAudioSet]);

  // Stop, unloads and changes song depending on route
  useEffect(() => {
    if (pathname === "/Game") {
      console.log("Changing to /Map route, stopping audio");
      setCurrentSong(1);
      unloadSound();
      setIsCurrentSongFirst(false);
    }
    if (pathname != "/Game") {
      console.log("Changing to routes other than /Game");
      setCurrentSong(0);
      isCurrentSongFirst ? "" : unloadSound();
      setIsCurrentSongFirst(true);
    }
  }, [pathname]);

  // Unload sound when needed
  async function unloadSound() {
    if (sound) {
      console.log("Unloading Sound");
      await sound.stopAsync();
      await sound.unloadAsync();
      setIsPlaying(false);
      setIsAudioSet(false);
      setSound(undefined);
      setStatus(undefined);
    }
  }

  // Set volume when sound is loaded or on user volume change
  useEffect(() => {
    if (sound) {
      sound.setVolumeAsync(volume);
    }
  }, [sound, volume]);

  // Playback status update
  useEffect(() => {
    if (sound) {
      sound.setOnPlaybackStatusUpdate((status) => setStatus(status));
    }
  }, [sound]);

  // Duration calculations
  const durationleft = status?.isLoaded ? status.positionMillis : 0;
  const songduration = status?.isLoaded ? status.durationMillis : 0;

  return (
    <>
      {/* <TouchableOpacity onPress={() => unloadSound()}>
        <Text>Stop</Text>
      </TouchableOpacity>
      <Text>
        {durationleft} - {songduration}
      </Text>
      <Text>{pathname}</Text> */}
    </>
  );
}
