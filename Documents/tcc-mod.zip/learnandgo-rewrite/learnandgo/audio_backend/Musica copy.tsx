import { getSongs } from "@/database_api/fetch";
import { AVPlaybackStatus, Audio } from "expo-av";
import { Sound } from "expo-av/build/Audio";
import { usePathname } from "expo-router";
import { useEffect, useState } from "react";
import { Button, TouchableOpacity } from "react-native";
import { Text } from "react-native";

export default function Musica() {
  const [songs, setSongs] = useState<any>(null);
  const [isAudioSet, setIsAudioSet] = useState(false);
  const [currentSong, setCurrentSong] = useState(0);
  const [sound, setSound] = useState<Sound>();
  const [status, setStatus] = useState<AVPlaybackStatus>();
  const [isPlaying, setIsPlaying] = useState(false);
  const [play, setPlay] = useState(false);
  const [volume, setVolume] = useState(1);
  const pathname = usePathname();

  useEffect(() => {
    const fetchSongs = async () => {
      const data = await getSongs();
      setSongs(data);
    };
    fetchSongs();
  }, []);

  async function setAudio() {
    console.log("Loading Sound");
    const { sound, status } = await Audio.Sound.createAsync({
      uri: songs[currentSong].tb08_sound_url,
    });
    sound.setIsLoopingAsync(true);
    setSound(sound);
    setStatus(status);
  }

  function playSound() {
    if (isPlaying) return;
    console.log("Playing Sound");
    sound?.playAsync();
    setIsPlaying(true);
  }

  function pauseSound() {
    if (!isPlaying) return;
    console.log("Pausing Sound");
    sound?.pauseAsync();
    setIsPlaying(false);
  }

  function unloadSound() {
    console.log("Unloading Sound");
    sound?.stopAsync();
    sound?.unloadAsync();
    setIsPlaying(false);
  }

  sound?.setVolumeAsync(volume);

  play ? playSound() : pauseSound();

  sound?.setOnPlaybackStatusUpdate((status) => setStatus(status));
  let durationleft = status?.isLoaded ? status.positionMillis : 0;
  let songduration = status?.isLoaded ? status.durationMillis : 0;

  if (!isAudioSet && sound) {
    setAudio();
    setIsAudioSet(true);
  }
  return (
    <>
      <TouchableOpacity onPress={() => setPlay(true)}>
        <Text>Play</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => setPlay(false)}>
        <Text>Stop</Text>
      </TouchableOpacity>
      <Text>
        {durationleft} - {songduration}
      </Text>
      <Text>{pathname}</Text>
    </>
  );
}
