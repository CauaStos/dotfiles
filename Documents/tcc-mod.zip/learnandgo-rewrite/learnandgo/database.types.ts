export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  graphql_public: {
    Tables: {
      [_ in never]: never;
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      graphql: {
        Args: {
          operationName?: string;
          query?: string;
          variables?: Json;
          extensions?: Json;
        };
        Returns: Json;
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
  public: {
    Tables: {
      tb01_users: {
        Row: {
          tb01_email: string;
          tb01_id: string;
          tb01_name: string;
          tb01_password: string;
          tb01_username: string;
        };
        Insert: {
          tb01_email: string;
          tb01_id?: string;
          tb01_name: string;
          tb01_password: string;
          tb01_username: string;
        };
        Update: {
          tb01_email?: string;
          tb01_id?: string;
          tb01_name?: string;
          tb01_password?: string;
          tb01_username?: string;
        };
        Relationships: [];
      };
      tb02_config: {
        Row: {
          tb02_id: string;
          tb02_jsonconfig: Json;
          tb02_userid: string;
        };
        Insert: {
          tb02_id?: string;
          tb02_jsonconfig: Json;
          tb02_userid: string;
        };
        Update: {
          tb02_id?: string;
          tb02_jsonconfig?: Json;
          tb02_userid?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tb02_config_tb02_userid_fkey";
            columns: ["tb02_userid"];
            isOneToOne: true;
            referencedRelation: "tb01_users";
            referencedColumns: ["tb01_id"];
          }
        ];
      };
      tb03_questions: {
        Row: {
          tb03_id: string;
          tb03_island: string;
          tb03_portalid: string;
          tb03_question: string;
          tb03_resp_1: string;
          tb03_resp_2: string;
          tb03_resp_3: string;
          tb03_resp_4: string;
        };
        Insert: {
          tb03_id?: string;
          tb03_island: string;
          tb03_portalid: string;
          tb03_question: string;
          tb03_resp_1: string;
          tb03_resp_2: string;
          tb03_resp_3: string;
          tb03_resp_4: string;
        };
        Update: {
          tb03_id?: string;
          tb03_island?: string;
          tb03_portalid?: string;
          tb03_question?: string;
          tb03_resp_1?: string;
          tb03_resp_2?: string;
          tb03_resp_3?: string;
          tb03_resp_4?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tb03_questions_tb03_portalid_fkey";
            columns: ["tb03_portalid"];
            isOneToOne: false;
            referencedRelation: "tb04_portals";
            referencedColumns: ["tb04_id"];
          }
        ];
      };
      tb04_portals: {
        Row: {
          tb04_animal: string | null;
          tb04_id: string;
          tb04_island: string;
          tb04_order: number | null;
        };
        Insert: {
          tb04_animal?: string | null;
          tb04_id?: string;
          tb04_island: string;
          tb04_order?: number | null;
        };
        Update: {
          tb04_animal?: string | null;
          tb04_id?: string;
          tb04_island?: string;
          tb04_order?: number | null;
        };
        Relationships: [
          {
            foreignKeyName: "tb04_portals_tb04_island_fkey";
            columns: ["tb04_island"];
            isOneToOne: false;
            referencedRelation: "tb05_island";
            referencedColumns: ["tb05_id"];
          }
        ];
      };
      tb05_island: {
        Row: {
          tb05_background: string | null;
          tb05_game_img: string | null;
          tb05_id: string;
          tb05_name: string;
          tb05_order: number;
          tb05_placa: string | null;
          tb05_portal_img: string | null;
          tb05_url_img: string;
        };
        Insert: {
          tb05_background?: string | null;
          tb05_game_img?: string | null;
          tb05_id?: string;
          tb05_name: string;
          tb05_order: number;
          tb05_placa?: string | null;
          tb05_portal_img?: string | null;
          tb05_url_img: string;
        };
        Update: {
          tb05_background?: string | null;
          tb05_game_img?: string | null;
          tb05_id?: string;
          tb05_name?: string;
          tb05_order?: number;
          tb05_placa?: string | null;
          tb05_portal_img?: string | null;
          tb05_url_img?: string;
        };
        Relationships: [];
      };
      tb06_island_progress: {
        Row: {
          tb06_have_tree: boolean;
          tb06_id: string;
          tb06_island: string;
          tb06_unlocked: boolean;
          tb06_userid: string;
        };
        Insert: {
          tb06_have_tree: boolean;
          tb06_id?: string;
          tb06_island: string;
          tb06_unlocked: boolean;
          tb06_userid: string;
        };
        Update: {
          tb06_have_tree?: boolean;
          tb06_id?: string;
          tb06_island?: string;
          tb06_unlocked?: boolean;
          tb06_userid?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tb06_island_progress_tb06_island_fkey";
            columns: ["tb06_island"];
            isOneToOne: false;
            referencedRelation: "tb05_island";
            referencedColumns: ["tb05_id"];
          },
          {
            foreignKeyName: "tb06_island_progress_tb06_userid_fkey";
            columns: ["tb06_userid"];
            isOneToOne: false;
            referencedRelation: "tb01_users";
            referencedColumns: ["tb01_id"];
          }
        ];
      };
      tb07_portal_progress: {
        Row: {
          tb07_completed: boolean | null;
          tb07_id: string;
          tb07_name_island: string;
          tb07_portal: string;
          tb07_unlocked: boolean;
          tb07_userid: string;
        };
        Insert: {
          tb07_completed?: boolean | null;
          tb07_id?: string;
          tb07_name_island: string;
          tb07_portal: string;
          tb07_unlocked: boolean;
          tb07_userid: string;
        };
        Update: {
          tb07_completed?: boolean | null;
          tb07_id?: string;
          tb07_name_island?: string;
          tb07_portal?: string;
          tb07_unlocked?: boolean;
          tb07_userid?: string;
        };
        Relationships: [
          {
            foreignKeyName: "tb07_portal_progress_tb07_portal_fkey";
            columns: ["tb07_portal"];
            isOneToOne: false;
            referencedRelation: "tb04_portals";
            referencedColumns: ["tb04_id"];
          },
          {
            foreignKeyName: "tb07_portal_progress_tb07_userid_fkey";
            columns: ["tb07_userid"];
            isOneToOne: false;
            referencedRelation: "tb01_users";
            referencedColumns: ["tb01_id"];
          }
        ];
      };
      tb08_sounds: {
        Row: {
          tb08_id: string;
          tb08_sound_name: string;
          tb08_sound_type: string | null;
          tb08_sound_url: string;
        };
        Insert: {
          tb08_id?: string;
          tb08_sound_name: string;
          tb08_sound_type?: string | null;
          tb08_sound_url: string;
        };
        Update: {
          tb08_id?: string;
          tb08_sound_name?: string;
          tb08_sound_type?: string | null;
          tb08_sound_url?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      consulta_mapa_user: {
        Args: {
          user_id: string;
        };
        Returns: {
          tb05_id: string;
          tb05_order: number;
          tb05_portal_img: string;
          tb05_url_img: string;
          tb06_have_tree: boolean;
          tb06_unlocked: boolean;
        }[];
      };
      get_portal_progress: {
        Args: {
          p_userid: string;
          p_island: string;
        };
        Returns: {
          tb07_userid: string;
          tb07_portal: string;
          tb07_unlocked: boolean;
          tb07_completed: boolean;
          tb04_order: number;
          tb04_island: string;
          tb05_portal_img: string;
          tb05_order: number;
          tb05_background: string;
        }[];
      };
      get_questions: {
        Args: {
          p_portalid: string;
        };
        Returns: {
          tb03_id: string;
          tb03_question: string;
          tb03_resp_1: string;
          tb03_resp_2: string;
          tb03_resp_3: string;
          tb03_resp_4: string;
          tb05_game_img: string;
          tb05_placa: string;
          tb04_animal: string;
        }[];
      };
      get_songs: {
        Args: Record<PropertyKey, never>;
        Returns: {
          tb08_sound_name: string;
          tb08_sound_url: string;
        }[];
      };
      insert_island_progress: {
        Args: {
          p_userid: string;
        };
        Returns: undefined;
      };
      insert_portal_progress: {
        Args: {
          p_userid: string;
        };
        Returns: undefined;
      };
      reset_portal_progress: {
        Args: {
          portal_id: string;
        };
        Returns: undefined;
      };
      unlock_portal: {
        Args: {
          portal_id: string;
        };
        Returns: undefined;
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type PublicSchema = Database[Extract<keyof Database, "public">];

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
      PublicSchema["Views"])
  ? (PublicSchema["Tables"] &
      PublicSchema["Views"])[PublicTableNameOrOptions] extends {
      Row: infer R;
    }
    ? R
    : never
  : never;

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
  ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
      Insert: infer I;
    }
    ? I
    : never
  : never;

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
  ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
      Update: infer U;
    }
    ? U
    : never
  : never;

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
  ? PublicSchema["Enums"][PublicEnumNameOrOptions]
  : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database;
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
  ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
  : never;
