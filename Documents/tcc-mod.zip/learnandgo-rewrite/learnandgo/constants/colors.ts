export const colors_signup = {
  text: "#dce8fa",
  background: "#09284f",
  primary: "#acb8c8",
  secondary: "#174b8b",
  accent: "#47e01f",
};
export const colors = {
  text: "#181818",
  background: "#f8f8fc",
  primary: "#02c59b",
  secondary: "#00a897",
  accent: "#4973DE",
  placeholder: "#B0B0B0",
  iconNavigationBar: "#000",
  iconNavigationBarWhite: "#fff" 
};
