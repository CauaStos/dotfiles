import { Dimensions, StyleSheet } from "react-native";
import { colors, colors_signup } from "./colors";

const dimensions_screen = Dimensions.get("screen");
export const styles = StyleSheet.create({
  background: {
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
  },

  background_inside: {
    justifyContent: "center",
  },
  font_size_normal: {
    fontSize: dimensions_screen.width * 0.04,
  },
  logo: {
    width: "100%",
  },
  button_wrapper: {
    width: "80%",
    height: "20%",
    justifyContent: "space-evenly",
  },
  signup_wrapper: {
    width: dimensions_screen.width * 0.8,
    height: dimensions_screen.height * 0.5,
    justifyContent: "space-evenly",
    alignItems: "center",
    borderRadius: 8,
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "rgba(255, 255, 255, 0.5)",
  },

  signup_input: {
    backgroundColor: "transparent",
    width: "80%",
    paddingHorizontal: 10,
    height: "12%",
    borderBottomWidth: 1,
    borderColor: colors.background,
    color: colors.background,
  },
  signup_input_active: {
    borderColor: colors.accent,
  },

  signin_reminders_section: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  button: {
    width: "100%",
    height: "40%",
    borderRadius: 5,
    alignItems: "center",
    justifyContent: "center",
  },
  button_general_signup: {
    width: "80%",
    height: "12%",
    backgroundColor: colors.background,
  },
  button_login_color: {
    backgroundColor: "#bb9d6f",
  },
  button_signup_color: {
    backgroundColor: colors.secondary,
  },
  floating_bar: {
    position: "absolute",
    flexDirection: "row",
    overflow: "hidden",
    width: "85%",
    height: "8%",
    left: "7.5%",
    bottom: "7%",
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
  },

  div_maps: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingBottom: 100,
    flexDirection: "column-reverse",
    flexGrow: 1,
  },

  map_image: {
    width: 130,
    objectFit: "cover",
    position: "absolute",
    transitionDuration: "300ms",
  },

  map_image_default: {
    height: 130,
  },

  map_image_with_tree: {
    height: 180,
  },

  ilha: {
    height: 50,
    width: 40,
    position: "absolute",
  },
  ilha_default_left: {
    right: 140,
  },

  ilha_default_with_tree: {
    top: 70,
  },

  ilha_default_no_tree: {
    top: 30,
  },

  ilha_default_right: {
    left: 140,
  },

  ilha_with_tree: {
    top: 20,
  },

  ilha_no_tree: {
    top: -20,
  },

  ilha_left: {
    height: 50,
    width: 40,
    right: 70,
    top: -20,
    position: "absolute",
  },

  ilha_right: {
    height: 50,
    width: 40,
    left: 70,
    top: -20,
    position: "absolute",
  },

  div_box_maps: {
    width: "90%",
    height: 130,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },

  map_left: {
    alignItems: "flex-start",
  },

  map_right: {
    alignItems: "flex-end",
  },

  gray_scale: {
    width: 130,
    position: "absolute",
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  gray_with_tree: {
    height: 180,
  },

  gray_no_tree: {
    height: 140,
  },

  scrollBox: {
    width: "100%",
    minHeight: 700,
    justifyContent: "flex-end",
    flexDirection: "column",
  },
  scrollContent: {
    paddingBottom: 20, // Garante que o conteúdo tenha espaçamento para rolagem
  },

  div_loading: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  box: {
    height: 80,
    width: 80,
    margin: 20,
    borderWidth: 1,
    borderColor: "#b58df1",
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    height: "100%",
  },
  popup: {
    position: "absolute",
    zIndex: 100,
    width: "100%",
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  popup_wrapper: {
    width: "90%",
    height: "10%",
    borderRadius: 10,
    backgroundColor: "#d6d6d6",
    top: "7%",
  },
  popup_title: {
    flexDirection: "row",
    height: "100%",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  popup_icon: {
    textAlign: "center",
    alignItems: "flex-end",
    color: colors.accent,
    marginRight: 10,
  },

  popup_title_color: {
    color: colors.text,
  },
  popup_title_text: {
    width: "80%",
  },
  popup_dismiss: {
    position: "absolute",
    top: 3,
    right: 3,
  },
  portalImage: {
    width: 100,
    height: 100,
  },

  div_portal: {
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "flex-start",
    paddingBottom: 140,
    flexDirection: "column-reverse",
    flexGrow: 1,
  },

  div_box_portal: {
    width: "90%",
    height: 130,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },

  gray_scale_portal: {
    width: 110,
    height: 110,
    position: "absolute",
    borderRadius: 100,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  profile_container: {
    marginTop: "12.5%",
    width: "80%",
    height: "80%",
    justifyContent: "space-evenly",
    alignItems: "center",
    display: "flex",
  },
  profile_picture: {
    width: dimensions_screen.width * 0.25,
    height: dimensions_screen.width * 0.25,
    borderRadius: 100,
  },
  switch_profile_picture: {
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    flexDirection: "row",
    marginTop: "2.5%",
    marginBottom: "10%",
  },
  settings_container: {
    paddingBottom: "5%",
    paddingLeft: "5%",
    paddingRight: "5%",
    width: "100%",
    height: "85%",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 10,
    overflow: "hidden",
    borderWidth: 2,
    borderColor: "rgba(255, 255, 255, 0.5)",
  },
  settings_inner_container: {
    width: "100%",
    height: "42.5%",
    justifyContent: "space-around",
  },
  settings_title: {
    paddingTop: "2.5%",
    borderBottomWidth: 1,
    borderColor: colors.background,
    alignItems: "center",
    justifyContent: "center",
    height: "20%",
  },
  settings_button: {
    width: "80%",
    height: "10%",
    backgroundColor: colors.accent,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 5,
  },
  game_body: {
    height: "100%",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "flex-start",
    backgroundColor: "#353640",
  },
  game_animal: {
    height: dimensions_screen.width * 0.67,
    width: dimensions_screen.width * 0.67,
    position: 'absolute',
    top: 230,
    // backgroundColor: 'red',
  },
  placa_game: {
    height: 200,
    width: 200,
    position: 'absolute',
    top: -20,
    left: 15,
    display: 'flex',
    flexDirection: 'row',
  },
  game_img: {
    width: "100%",
    height: 500,
    display: "flex",
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center'
  },
  asked_box: {
    width: dimensions_screen.width * 1,
    height: dimensions_screen.width * 0.26,
  },
  asked_text: {
    paddingLeft: 20,
    paddingTop: 10,
    width: '100%',
    height: '100%',
    fontSize: 20,
  },
  box_of_aeswer: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    marginTop: 10,
  },
  aeswer_box: {
    width: dimensions_screen.width * 0.48,
    height: dimensions_screen.width * 0.24,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
     backgroundColor: '#F0EFEA'
  },
  aeswer_text: {
    textAlign: "center",
    fontSize: 20,
  },
  game_row: {
    width: "100%",
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-evenly",
    marginBottom: 5,
  },
  box_hits: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
    width: 200,
    height: 90,
    position: 'absolute',
    bottom: 0,
  },
  game_hits: {
    width: 55,
    height: 55,
  }
});

export const font = StyleSheet.create({
  title: {
    fontSize: dimensions_screen.width * 0.07,
    fontFamily: "Roboto_700Bold",
  },
  subtitle: {
    fontSize: dimensions_screen.width * 0.055,
    fontFamily: "Roboto_500Medium",
  },
  body: {
    fontSize: dimensions_screen.width * 0.0445,
    fontWeight: "400",
    fontFamily: "Roboto_400Regular",
  },
  input: {
    fontSize: dimensions_screen.width * 0.0445,
    fontFamily: "Roboto_500Medium",
  },
  action: {
    fontSize: dimensions_screen.width * 0.04,
    fontFamily: "Roboto_400Regular",
  },
  description: {
    fontSize: dimensions_screen.width * 0.03,
    fontFamily: "Roboto_400Regular",
  },
  buttonText: {
    fontSize: dimensions_screen.width * 0.045,
    fontFamily: "Roboto_700Bold",
  },
  text_black: {
    color: colors.text,
  },
  text_white: {
    color: colors.background,
  },
  text_accent: {
    color: colors.accent,
  },
  text_underscore: {
    borderBottomWidth: 1,
    borderBottomColor: colors.background,
  },
});
