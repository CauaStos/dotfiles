import CustomInput from "@/components/global/CustomInput";
import { colors } from "@/constants/colors";
import { font, styles } from "@/constants/style";
import { BlurView } from "expo-blur";
import { useRef, useState } from "react";
import {
  Button,
  ImageBackground,
  Pressable,
  Text,
  Touchable,
  TouchableHighlight,
  TouchableOpacity,
  View,
} from "react-native";
import Checkbox from "expo-checkbox";
import { Link, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
const background = require("@/assets/images/background-primary.jpeg");

export default function Login() {
  const [userIsFocused, setUserIsFocused] = useState(false);
  const [passwordIsFocused, setPasswordIsFocused] = useState(false);

  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [isChecked, setChecked] = useState(false);
  return (
    <ImageBackground
      source={background}
      resizeMode="cover"
      style={[styles.background, { justifyContent: "center" }]}
    >
      <TouchableOpacity
        onPress={() => {
          router.push("/(tabs)/Map");
        }}
        style={{ position: "absolute", left: "5%", top: "5%", zIndex: 10 }}
        activeOpacity={0.8}
      >
        <Ionicons
          name="chevron-back-outline"
          size={50}
          color={colors.background}
        />
      </TouchableOpacity>
      <BlurView
        experimentalBlurMethod="dimezisBlurView"
        intensity={40}
        style={[styles.signup_wrapper]}
        tint="systemUltraThinMaterialDark"
      >
        <Text style={[font.title, font.text_white]}>Login</Text>
        <CustomInput
          state_variable={userIsFocused}
          state_function={setUserIsFocused}
          placeholder="Usuário"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setUser}
        />
        <CustomInput
          state_variable={passwordIsFocused}
          state_function={setPasswordIsFocused}
          placeholder="Senha"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setPassword}
        />
        <View style={styles.signin_reminders_section}>
          <TouchableHighlight
            underlayColor={"transparent"}
            style={font.text_underscore}
            onPress={() => router.push("/Cadastro")}
          >
            <Text style={[font.description, font.text_white]}>Criar conta</Text>
          </TouchableHighlight>
          <TouchableHighlight
            underlayColor={"transparent"}
            onPress={() => router.push("/Esqueceu")}
          >
            <Text style={[font.description, font.text_white]}>
              Esqueceu a senha?
            </Text>
          </TouchableHighlight>
        </View>
        <TouchableOpacity
          style={[styles.button, styles.button_general_signup]}
          onPress={() => {
            {
              //QueryUser();
            }
          }}
          activeOpacity={0.7}
        >
          <Text style={[font.buttonText]}>Entrar</Text>
        </TouchableOpacity>
      </BlurView>
    </ImageBackground>
  );
}
