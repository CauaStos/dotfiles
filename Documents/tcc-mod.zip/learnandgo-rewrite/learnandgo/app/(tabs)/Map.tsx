import { styles } from "@/constants/style";
import {
  ImageBackground,
  Text,
  View,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { MapsComp } from "@/components/global/mapsComp";
import { getMaps } from "@/database_api/fetch";

import { useEffect, useRef, useState } from "react";
import PopUp from "@/components/global/PopUp";

interface PropsMap {
  tb06_have_tree: boolean;
  tb06_unlocked: boolean;
  tb05_order: number;
  tb05_portal_img: string;
  tb05_url_img: string;
  tb05_id: string;
}

export default function TabOneScreen() {
  const userId = "32989314-c6fc-43a9-93aa-7da17f78073d";
  const [isLoading, setIsLoading] = useState(true);
  const [background, setBackgound] = useState(0);
  const [data, setData] = useState<PropsMap[]>([]);
  const [popup_message, setPopupMessage] = useState("");
  const [popup, setPopup] = useState(false);
  const [loadingMensage, setLoadingMensage] = useState("");
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);

      setBackgound(require("../../assets/images/fundo-mapa.jpg"));
      const pegandoMapas = await getMaps(userId.toString(), setLoadingMensage);
      setData(Array.isArray(pegandoMapas) ? (pegandoMapas as PropsMap[]) : []);

      setIsLoading(false);

      // Ajusta a posição do scroll para o final após o carregamento dos dados
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: false });
      }, 0);
    };
    fetchData();
  }, []);

  function mapScreen() {
    if (isLoading) {
      return (
        <View style={styles.div_loading}>
          <ActivityIndicator size="large" color="#0000ff" />
          <Text>{loadingMensage}</Text>
        </View>
      );
    }

    return (
      <ImageBackground
        source={background}
        style={{ width: "100%", height: "100%" }}
      >
        {popup && (
          <PopUp
            popup_message={popup_message}
            popup_state={popup}
            popup_state_function={setPopup}
          />
        )}

        <ScrollView
          ref={scrollViewRef}
          contentContainerStyle={{
            flexGrow: 1,
            paddingBottom: 40,
            paddingTop: 20,
          }}
          style={{ flex: 1 }}
          onContentSizeChange={() =>
            scrollViewRef.current?.scrollToEnd({ animated: true })
          }
        >
          <View style={[styles.div_maps, { flexDirection: "column-reverse" }]}>
            {data.map((value: PropsMap, index) => (
              <MapsComp
                id={value.tb05_id}
                mapCode={value.tb05_order}
                direction={index % 2 === 0 ? "right" : "left"}
                haveTree={value.tb06_have_tree}
                image={value.tb05_url_img}
                unLocked={value.tb06_unlocked}
                setAlert={setPopup}
                setMensage={setPopupMessage}
                key={value.tb05_order}
                finaly={index === data.length - 1}
                userId={userId.toString()}
              />
            ))}
          </View>
        </ScrollView>
      </ImageBackground>
    );
  }

  return mapScreen();
}
