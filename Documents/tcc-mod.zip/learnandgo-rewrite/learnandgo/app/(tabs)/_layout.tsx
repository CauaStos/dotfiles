import { Slot, Tabs } from "expo-router";
import { colors } from "@/constants/colors";
import { Ionicons } from "@expo/vector-icons";
import { styles } from "@/constants/style";
import { BlurView } from "expo-blur";
import { Link } from "expo-router";

import {
  Roboto_100Thin,
  Roboto_100Thin_Italic,
  Roboto_300Light,
  Roboto_300Light_Italic,
  Roboto_400Regular,
  Roboto_400Regular_Italic,
  Roboto_500Medium,
  Roboto_500Medium_Italic,
  Roboto_700Bold,
  Roboto_700Bold_Italic,
  Roboto_900Black,
  Roboto_900Black_Italic,
  useFonts,
} from "@expo-google-fonts/roboto";
import * as SplashScreen from "expo-splash-screen";

import { useEffect, useState } from "react";
import { View } from "react-native";
import FloatingBar from "@/components/global/FloatingBar";
import Stack from "expo-router/stack";
import { StatusBar } from "expo-status-bar";
//import { Audio } from "expo-av";
//const musica = require("@/assets/songs/musica.mp3");

type LayoutProps = {
  children: React.ReactNode;
};

SplashScreen.hide();

export default function TabLayout({ children }: LayoutProps) {
  // const [sound, setSound] = useState<Audio.Sound | null>(null);

  // useEffect(() => {
  //   let playbackObject: Audio.Sound;

  //   const loadAudio = async () => {
  //     try {
  //       playbackObject = new Audio.Sound();
  //       await playbackObject.loadAsync(musica);
  //       setSound(playbackObject);
  //       await playbackObject.playAsync(); // Play the audio
  //     } catch (error) {
  //       console.error("Error loading audio:", error);
  //     }
  //   };

  //   loadAudio();

  //   return () => {
  //     // Cleanup the audio resource
  //     if (playbackObject) {
  //       playbackObject.unloadAsync();
  //     }
  //   };
  // }, []);

  return (
    <>
      <StatusBar hidden />
      <Stack
        screenOptions={{
          headerShown: false, // Hide the header
          animation: "slide_from_right",
          animationTypeForReplace: "push",
        }}
      >
        <Stack.Screen
          name="Map"
          options={{ headerShown: false, animation: "slide_from_left" }}
        />
        <Stack.Screen
          name="Level"
          options={{ headerShown: false, animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="Settings"
          options={{ headerShown: false, animation: "slide_from_right" }}
        />
      </Stack>
      <FloatingBar />
      {/* <StatusBar hidden />
      <Slot />
      <FloatingBar /> */}
    </>
  );
}
