import { styles } from "@/constants/style";
import { useLocalSearchParams } from "expo-router";
import { ImageBackground, Text, View, ActivityIndicator } from "react-native";
import { getLevelsUser } from "@/database_api/fetch";
import { useEffect, useState } from "react";
import PortalComp from "@/components/global/portalComp";
import { memo } from "react";

interface PropsMap {
  tb07_userid: string;
  tb07_portal: string;
  tb07_unlocked: boolean;
  tb07_completed: boolean;
  tb04_order: number;
  tb04_island: string;
  tb05_portal_img: string;
  tb05_order: number;
  tb05_background: string;
}

export default memo(function Level() {
  const { map, userId } = useLocalSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<PropsMap[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);

      try {
        const levelData = await getLevelsUser(
          userId?.toString(),
          map?.toString()
        );
        setData(Array.isArray(levelData) ? (levelData as PropsMap[]) : []);
      } catch (error) {
        console.error("Erro ao buscar os dados:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [userId, map]);

  if (isLoading) {
    return (
      <View style={styles.div_loading}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Carregando...</Text>
      </View>
    );
  }

  if (data.length === 0) {
    return (
      <View style={styles.div_loading}>
        <Text>Nenhum dado disponível.</Text>
      </View>
    );
  }

  return (
    <ImageBackground
      resizeMode="cover"
      source={{ uri: data[0]?.tb05_background }}
      style={{ width: "100%", height: "100%", backgroundPosition: "bottom" }}
    >
      <View style={styles.div_portal}>
        {data.map((value: PropsMap) => {
          return (
            <PortalComp
              portalCode={value.tb07_portal}
              mapCode={value.tb04_island}
              unLocked={value.tb07_unlocked}
              portalImage={value.tb05_portal_img}
              mapOrder={value.tb05_order}
              levelOrder={value.tb04_order}
              key={value.tb07_portal}
              map={map.toString()}
              userId={userId.toString()}
              completed={value.tb07_completed}
            />
          );
        })}
      </View>
    </ImageBackground>
  );
});
