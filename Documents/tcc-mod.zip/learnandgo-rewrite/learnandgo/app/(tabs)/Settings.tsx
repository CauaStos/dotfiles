import AudioSettings from "@/components/global/AudioSettings";
import UserSettings from "@/components/global/UserSettings";
import { colors } from "@/constants/colors";
import { font, styles } from "@/constants/style";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import {
  Dimensions,
  Image,
  ImageBackground,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const background = require("@/assets/images/background-primary.jpeg");

const profile_picture_placeholder = require("@/assets/images/profile-picture-default.jpeg");
export default function Settings() {
  return (
    <ImageBackground source={background} style={[styles.background]}>
      <View style={styles.profile_container}>
        <View>
          <Image
            source={profile_picture_placeholder}
            style={styles.profile_picture}
          />
          <TouchableOpacity style={styles.switch_profile_picture}>
            <Text style={[font.action, font.text_white]}>Trocar Foto </Text>
            <Ionicons
              name="create-outline"
              size={Dimensions.get("screen").width * 0.045}
              style={font.text_white}
            />
          </TouchableOpacity>
        </View>
        <BlurView
          experimentalBlurMethod="dimezisBlurView"
          intensity={60}
          tint="dark"
          style={styles.settings_container}
        >
          <UserSettings
            container_style={styles.settings_inner_container}
            title_style={[
              styles.settings_title,
              font.subtitle,
              font.text_white,
            ]}
            text_style={[font.action, font.text_white]}
          />
          <AudioSettings
            container_style={styles.settings_inner_container}
            title_style={[
              styles.settings_title,
              font.subtitle,
              font.text_white,
            ]}
            text_style={[font.action, font.text_white]}
            thumb_tint_color={colors.accent}
            min_tint_color={colors.accent}
            max_tint_color={colors.placeholder}
          />
          <TouchableOpacity style={[styles.settings_button]}>
            <Text style={[font.buttonText, font.text_white]}>Salvar</Text>
          </TouchableOpacity>
        </BlurView>
      </View>
    </ImageBackground>
  );
}
