import { Stack } from "expo-router/stack";
import {
  Roboto_100Thin,
  Roboto_100Thin_Italic,
  Roboto_300Light,
  Roboto_300Light_Italic,
  Roboto_400Regular,
  Roboto_400Regular_Italic,
  Roboto_500Medium,
  Roboto_500Medium_Italic,
  Roboto_700Bold,
  Roboto_700Bold_Italic,
  Roboto_900Black,
  Roboto_900Black_Italic,
  useFonts,
} from "@expo-google-fonts/roboto";
import * as SplashScreen from "expo-splash-screen";

import React, { Suspense, useEffect, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { colors } from "@/constants/colors";
import { router, useFocusEffect, usePathname } from "expo-router";
import { Text } from "react-native";
import { TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { BackHandler } from "react-native";
import Musica from "@/audio_backend/Musica";

SplashScreen.hide();

export default function Layout() {
  return (
    <>
      <StatusBar hidden />
      <Stack
        screenOptions={{
          headerShown: false,
          headerTintColor: colors.background,
          headerTitle: "",
          headerTransparent: true,
          presentation: "card",
        }}
        initialRouteName="Login"
      >
        <Stack.Screen
          name="Login"
          options={{
            animation: "slide_from_left",
          }}
        />
        <Stack.Screen
          name="Cadastro"
          options={{ animation: "slide_from_right" }}
        />
        <Stack.Screen
          name="(tabs)"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="Game"
          options={{ animation: "slide_from_bottom" }}
        />
      </Stack>
      <Suspense>
        <Musica />
      </Suspense>
    </>
  );
}
