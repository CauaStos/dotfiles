import { styles } from "@/constants/style";

import { router, useFocusEffect, useLocalSearchParams } from "expo-router";
import { Text, View, ActivityIndicator } from "react-native";
import { useCallback, useEffect, useState } from "react";
import { Image } from "react-native";

import { getFase } from "@/database_api/fetch";

import LevelImg from "@/components/global/GamelImg";
import GamePlate from "@/components/global/GamePlate";
import AskedBox from "@/components/global/AskedBox";
import BoxOfAeswer from "@/components/global/boxOfQuestions";

interface PropsGame {
  tb03_id: string;
  tb03_question: string;
  tb03_resp_1: string;
  tb03_resp_2: string;
  tb03_resp_3: string;
  tb03_resp_4: string;
  tb05_game_img: string;
  tb05_placa: string;
  tb04_animal: string;
}

export default function Game() {
  const { levelId, map, userId } = useLocalSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState<PropsGame[]>([]);
  const [questions, setQuestions] = useState(0);
  const [hits, setHits] = useState(0);
  const [final, setFinal] = useState(false);

  useEffect(() => {
    if(final) {

      

      return router.push({
        pathname: "/Level",
        params: { map, userId },
      });
    }
  }, [final, map, userId])

  const [plate1, setPlate1] = useState("gray");
  const [plate2, setPlate2] = useState("gray");
  const [plate3, setPlate3] = useState("gray");

  useFocusEffect(
    useCallback(() => {
      const fetchData = async () => {
        setIsLoading(true);

        const levelData = await getFase(
          Array.isArray(levelId) ? levelId[0] : levelId
        ); // Garantir que retorna um array
        setData(Array.isArray(levelData) ? (levelData as PropsGame[]) : []);

        setIsLoading(false);
        levelScreen();
      };

      fetchData();
    }, [levelId])
  );
  function levelScreen() {
    if (isLoading) {
      // Mostrar o indicador de carregamento
      return (
        <View style={styles.div_loading}>
          <ActivityIndicator size="large" color="#0000ff" />
          <Text>Carregando...</Text>
        </View>
      );
    }

    return (
      <View style={styles.game_body}>
        <LevelImg imgFundo={data[0].tb05_game_img}>
          <GamePlate
            imgPlate={data[0].tb05_placa}
            plate1={plate1}
            plate2={plate2}
            plate3={plate3}
          />

          <Image style={styles.game_animal} src={data[0].tb04_animal} />
        </LevelImg>

        <AskedBox>
          <Text style={styles.asked_text}>{data[questions].tb03_question}</Text>
        </AskedBox>

        <View style={styles.box_of_aeswer}>
          <View style={styles.game_row}>
            <BoxOfAeswer
              isCorrect={true}
              functionQuestion={setQuestions}
              valueQuestion={questions}
              map={map.toString()}
              userId={userId.toString()}
              setPlate1={setPlate1}
              setPlate2={setPlate2}
              setPlate3={setPlate3}
              hits={hits}
              setHits={setHits}
              setFinal={setFinal}
            >
              <Text style={styles.aeswer_text}>
                {data[questions].tb03_resp_1}
              </Text>
            </BoxOfAeswer>

            <BoxOfAeswer
              isCorrect={false}
              functionQuestion={setQuestions}
              valueQuestion={questions}
              map={map.toString()}
              userId={userId.toString()}
              setPlate1={setPlate1}
              setPlate2={setPlate2}
              setPlate3={setPlate3}
              hits={hits}
              setHits={setHits}
              setFinal={setFinal}
            >
              <Text style={styles.aeswer_text}>
                {data[questions].tb03_resp_2}
              </Text>
            </BoxOfAeswer>
          </View>

          <View style={styles.game_row}>
            <BoxOfAeswer
              isCorrect={false}
              functionQuestion={setQuestions}
              valueQuestion={questions}
              map={map.toString()}
              userId={userId.toString()}
              setPlate1={setPlate1}
              setPlate2={setPlate2}
              setPlate3={setPlate3}
              hits={hits}
              setHits={setHits}
              setFinal={setFinal}
            >
              <Text style={styles.aeswer_text}>
                {data[questions].tb03_resp_3}
              </Text>
            </BoxOfAeswer>

            <BoxOfAeswer
              isCorrect={false}
              functionQuestion={setQuestions}
              valueQuestion={questions}
              map={map.toString()}
              userId={userId.toString()}
              setPlate1={setPlate1}
              setPlate2={setPlate2}
              setPlate3={setPlate3}
              hits={hits}
              setHits={setHits}
              setFinal={setFinal}
            >
              <Text style={styles.aeswer_text}>
                {data[questions].tb03_resp_4}
              </Text>
            </BoxOfAeswer>
          </View>
        </View>
      </View>
    );
  }

  return levelScreen();
}
