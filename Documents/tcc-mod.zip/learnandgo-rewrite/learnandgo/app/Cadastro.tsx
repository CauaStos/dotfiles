import PopUp from "@/components/global/PopUp";
import { colors } from "@/constants/colors";
import { font, styles } from "@/constants/style";
import { CheckConflictingUsers, InsertUser } from "@/database_api/signup";
import { getUserId } from "@/database_api/fetch"; // ---- Função para pegar id do user
import { BlurView } from "expo-blur";
import { useState } from "react";
import { ImageBackground, Text, TouchableOpacity } from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { BackHandler } from "react-native";
import CustomInput from "@/components/global/CustomInput";

const background = require("@/assets/images/background-primary.jpeg");

function CheckEmptyInput(
  email: string,
  name: string,
  username: string,
  password: string,
) {
  const empty_input_message = "Preencha todos os dados.";
  if (email && name && username && password) return null;
  return empty_input_message;
}

export default function Cadastro() {
  const [nameIsFocused, setNameIsFocused] = useState(false);
  const [emailIsFocused, setEmailIsFocused] = useState(false);
  const [userIsFocused, setUserIsFocused] = useState(false);
  const [passwordIsFocused, setPasswordIsFocused] = useState(false);

  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [popup_message, setPopupMessage] = useState("");
  const [popup, setPopup] = useState(false);

  // --------------- Função para pegar o id do usuário e ir para maps ----------------
  const goToMaps = async () => {
    const pegandoMapas = await getUserId(username); // Garantir que retorna um array
    console.log(pegandoMapas);

    pegandoMapas?.map((value, index) => {
      router.push({
        pathname: "/Map",
        params: { userId: value.tb01_id },
      });
    });
  };
  // ----------------------------------------------------------------------------------

  BackHandler.addEventListener("hardwareBackPress", () => {
    router.push("/Login");
    return true;
  });

  return (
    <ImageBackground
      source={background}
      resizeMode="cover"
      style={[styles.background, { justifyContent: "center" }]}
    >
      <TouchableOpacity
        onPress={() => {
          router.push("/Login");
        }}
        style={{ position: "absolute", left: "5%", top: "5%" }}
        activeOpacity={0.8}
      >
        <Ionicons
          name="chevron-back-outline"
          size={50}
          color={colors.background}
        />
      </TouchableOpacity>
      {popup ? (
        <PopUp
          popup_message={popup_message}
          popup_state={popup}
          popup_state_function={setPopup}
        />
      ) : (
        ""
      )}
      <BlurView
        experimentalBlurMethod="dimezisBlurView"
        intensity={40}
        style={[styles.signup_wrapper]}
        tint="systemUltraThinMaterialDark"
      >
        <Text style={[font.title, font.text_white]}>Cadastro</Text>
        <CustomInput
          state_variable={nameIsFocused}
          state_function={setNameIsFocused}
          placeholder="Insira seu nome"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setName}
        />
        <CustomInput
          state_variable={emailIsFocused}
          state_function={setEmailIsFocused}
          placeholder="Insira seu email"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setEmail}
        />
        <CustomInput
          state_variable={userIsFocused}
          state_function={setUserIsFocused}
          placeholder="Insira seu nome de usuário"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setUsername}
        />
        <CustomInput
          state_variable={passwordIsFocused}
          state_function={setPasswordIsFocused}
          placeholder="Insira sua senha"
          placeholder_color={colors.background}
          style={[styles.signup_input, font.input]}
          style_on_focus={styles.signup_input_active}
          input_state={setPassword}
        />
        <TouchableOpacity
          style={[styles.button, styles.button_general_signup]}
          onPress={async () => {
            console.log("------------------------------");
            console.log(
              `email ${email}, senha: ${password}, usuario: ${username}, nome: ${name}`,
            );
            console.log("------------------------------");
            let signup_error_message = CheckEmptyInput(
              email,
              name,
              username,
              password,
            );
            if (!signup_error_message)
              signup_error_message = await CheckConflictingUsers(
                email,
                username,
              );

            if (!signup_error_message) {
              InsertUser(email, name, username, password);

              goToMaps(); // ----- Chama a função para ir para Maps

              return;
            }
            setPopupMessage(signup_error_message);
            setPopup(true);
          }}
          activeOpacity={0.7}
        >
          <Text style={[font.buttonText]}>Registrar</Text>
        </TouchableOpacity>
      </BlurView>
    </ImageBackground>
  );
}
