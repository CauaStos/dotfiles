import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Database } from "@/database.types";
import { Platform } from "react-native";
import { criaMaps, criaFases } from "@/database_api/insert";

const supabaseUrl = "https://sshrzrdngkqpvcvdfikr.supabase.co";
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_KEY || "";

const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export async function getUserId(userName: string) {
  const { data, error } = await supabase
    .from("tb01_users")
    .select("tb01_id")
    .eq("tb01_username", userName);

  if (error) console.log(error);
  else return Array.isArray(data) ? data : [];
}

export async function getMaps(
  user: string,
  setMensage: React.Dispatch<React.SetStateAction<string>>,
) {
  setMensage("Carregando....");
  const { data, error } = await supabase.rpc("consulta_mapa_user", {
    user_id: user,
  });

  if (error) console.error(error);
  else {
    if (data.length === 0) {
      setMensage("Criando mapas....");
      await criaMaps(user);

      setMensage("Criando fases....");
      await criaFases(user);

      setMensage("Finalizando....");
      const { data, error } = await supabase.rpc("consulta_mapa_user", {
        user_id: user,
      });
      return Array.isArray(data) ? data : [];
    }
    return Array.isArray(data) ? data : [];
  }
}

export async function getLevelsUser(user: string, map: string) {
  const { data, error } = await supabase.rpc("get_portal_progress", {
    p_userid: user,
    p_island: map,
  });

  if (error) console.error(error);
  else return Array.isArray(data) ? data : [];
}

export async function getBackgroundLevel(userId: string, levelId: string) {
  const { data, error } = await supabase.rpc("get_portal_progress", {
    p_userid: userId,
    p_island: levelId,
  });

  if (error) console.error(error);
  else return Array.isArray(data) ? data : [];
}

export async function getFase(portalId: string) {
  const { data, error } = await supabase.rpc("get_questions", {
    p_portalid: portalId,
  });

  if (error) console.error(error);
  else return Array.isArray(data) ? data : [];
}

export async function getSongs() {
  const { data, error } = await supabase.rpc("get_songs");
  return data;
}
