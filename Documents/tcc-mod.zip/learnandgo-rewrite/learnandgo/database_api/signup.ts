console.log(process.env); // remove this after you've confirmed it is working
import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Database } from "@/database.types";
import { Platform } from "react-native";

const supabaseUrl = "https://sshrzrdngkqpvcvdfikr.supabase.co";
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_KEY;

const supabase = createClient<Database>(supabaseUrl, supabaseKey!, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export async function QueryUsername(username: string) {
  const { data, error } = await supabase
    .from("tb01_users")
    .select("tb01_username")
    .eq("tb01_username", username);
  console.log(`QueryUsername error: ${error}`);
  console.log(`QueryUsername data:`, data);
  console.log(data);
  console.log("------------------------------");
  return data[0];
}

export async function QueryEmail(email: string) {
  const { data, error } = await supabase
    .from("tb01_users")
    .select("tb01_email")
    .eq("tb01_email", email);
  console.log(`QueryEmail error: ${error}`);
  console.log(`QueryEmail data:`, data);
  console.log("------------------------------");

  return data[0];
}

export async function InsertUser(
  email: string,
  name: string,
  username: string,
  password: string
) {
  const { error } = await supabase.from("tb01_users").insert({
    tb01_email: email,
    tb01_name: name,
    tb01_password: password,
    tb01_username: username,
  });
  return error;
}

export async function CheckConflictingUsers(email: string, username: string) {
  const username_query = await QueryUsername(username);
  const email_query = await QueryEmail(email);

  //debugging:
  console.log(`conflict email: ${JSON.stringify(username_query)}`);
  console.log(`conflict username: ${JSON.stringify(email_query)}`);
  console.log("------------------------------");
  //

  if (email_query && username_query)
    return "Email e Nome de Usuário já cadastrados.";
  if (email_query) return "Email já cadastrado.";
  if (username_query) return "Nome de Usuário já existe.";
  return null;
}
