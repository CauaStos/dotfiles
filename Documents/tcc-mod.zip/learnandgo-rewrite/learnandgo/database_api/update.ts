import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Database } from "@/database.types";
import { Platform } from "react-native";

const supabaseUrl = "https://sshrzrdngkqpvcvdfikr.supabase.co";
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_KEY || "";

const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export async function setLevelProgress(portalId: string, userId: string) {
    const {data, error} = await supabase.rpc('')
}