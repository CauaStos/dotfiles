import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { Database } from "@/database.types";
import { Platform } from "react-native";

const supabaseUrl = "https://sshrzrdngkqpvcvdfikr.supabase.co";
const supabaseKey = process.env.EXPO_PUBLIC_SUPABASE_KEY || "";

const supabase = createClient<Database>(supabaseUrl, supabaseKey, {
  auth: {
    ...(Platform.OS !== "web" ? { storage: AsyncStorage } : {}),
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export async function criaMaps(user: string) {
    const { data, error } = await supabase.rpc("insert_island_progress", {
      p_userid: user,
    });
  
    if (error) console.log(error);
  
    return true;
  }
  
export async function criaFases(user: string) {
    const { data, error } = await supabase.rpc("insert_portal_progress", {
      p_userid: user,
    });
  
    if (error) console.log(error);
  
    return true;
}