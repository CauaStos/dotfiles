import { TouchableWithoutFeedback, View, Image, Alert } from "react-native";
import { BlurView } from "expo-blur";
import { router } from "expo-router";
import { styles } from "@/constants/style";
import Entypo from "@expo/vector-icons/Entypo";

import { useEffect, useState } from "react";

interface Props {
  id: string;
  image: string;
  haveTree?: boolean;
  unLocked?: boolean;
  direction: string;
  finaly?: boolean;
  mapCode: number;
  setAlert: React.Dispatch<React.SetStateAction<boolean>>;
  setMensage: React.Dispatch<React.SetStateAction<string>>;
  userId: string;
}

export const MapsComp = (props: Props) => {
  const ilha = require("@/assets/images/ilha-default.png");
  const [valueAnimation, setValueAnimation] = useState(0);
  const [directionAnimation, setDirectionAnimation] = useState(true);
  const [atualizaAnimation, setAtualizaAnimation] = useState(true);
  const [imgMap, setImgMapa] = useState("");

  useEffect(() => {
    setImgMapa(props.image);
  }, [props.image]);

  const animationBigIlha = () => {
    if (!props.unLocked) {
      return;
    }
    directionAnimation
      ? setValueAnimation(valueAnimation + 0.5)
      : setValueAnimation(valueAnimation - 0.5);

    if (valueAnimation >= 3) {
      setDirectionAnimation(false);
    } else if (valueAnimation <= -3) {
      setDirectionAnimation(true);
    }
  };

  // useEffect(() => {
  //   animationBigIlha();
  // }, [atualizaAnimation]);

  setTimeout(() => {
    animationBigIlha();
  }, 100);

  const goToLevel = async () => {
    if (!props.unLocked) {
      Alert.alert("Fase Bloqueada", "", [
        {
          text: "Cancel",
          // onPress: () => ,
          style: "cancel",
        },
        { text: "OK" },
      ]);
      return;
    }
    Alert.alert("Deseja fazer essa fase?", "", [
      {
        text: "Cancel",
        // onPress: () => console.log("Cancel Pressed"),
        style: "cancel",
      },
      {
        text: "OK",
        onPress: () =>
          router.push({
            pathname: "/Level",
            params: { map: props.id, userId: props.userId},
          }),
      },
    ]);
  };

  return (
    <View
      style={[
        styles.div_box_maps,
        // props.direction === "left" ? styles.map_left : styles.map_right,
        styles.map_image_with_tree,
      ]}
    >
      <TouchableWithoutFeedback onPress={goToLevel}>
        <Image
          src={imgMap}
          style={[
            styles.map_image,
            props.haveTree
              ? styles.map_image_with_tree
              : styles.map_image_default,
            props.direction === "left" ? { left: 0 } : { right: 0 },
            { transform: [{ translateY: valueAnimation }] },
          ]}
        />
      </TouchableWithoutFeedback>

      {!props.finaly ? (
        <>
          <Image
            source={ilha}
            style={[
              styles.ilha,
              props.direction === "left"
                ? styles.ilha_default_left
                : styles.ilha_default_right,
              props.haveTree ? { top: 70 } : { top: 30 },
              { transform: [{ translateY: valueAnimation }] },
            ]}
          />
          <Image
            source={ilha}
            style={[
              props.direction === "left" ? styles.ilha_left : styles.ilha_right,
              props.haveTree ? { top: 20 } : { top: -20 },
              { transform: [{ translateY: valueAnimation }] },
            ]}
          />
        </>
      ) : null}

      {!props.unLocked ? (
        <TouchableWithoutFeedback onPress={goToLevel}>
          <BlurView
            experimentalBlurMethod="dimezisBlurView"
            intensity={40}
            style={[
              styles.gray_scale,
              styles.map_image_with_tree,
              props.direction === "left" ? { left: 0 } : { right: 0 },
            ]}
            tint="dark"
          >
            <Entypo
              name="lock"
              size={70}
              color="white"
              style={{ opacity: 1 }}
            />
          </BlurView>
        </TouchableWithoutFeedback>
      ) : (
        ""
      )}
    </View>
  );
};
