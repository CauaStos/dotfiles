import { Ionicons } from "@expo/vector-icons";
import { Text, TextStyle, View, ViewStyle } from "react-native";
import Slider from "@react-native-community/slider";

interface Props {
  container_style: ViewStyle | ViewStyle[];
  title_style: TextStyle | TextStyle[];
  options_style?: ViewStyle | ViewStyle[];
  text_style: TextStyle | TextStyle[];
  slider_style?: ViewStyle | ViewStyle[];
  min_tint_color: string;
  max_tint_color: string;
  thumb_tint_color: string;
}

export default function AudioSettings(props: Props) {
  return (
    <View style={props.container_style}>
      <Text style={props.title_style}>Configurações de Áudio</Text>
      <View style={[, props.options_style]}>
        <Text style={props.text_style}>Geral</Text>
        <Slider
          style={props.slider_style}
          minimumValue={0}
          maximumValue={1}
          minimumTrackTintColor={props.min_tint_color}
          maximumTrackTintColor={props.max_tint_color}
          thumbTintColor={props.thumb_tint_color}
        />
      </View>
      <View style={[, props.options_style]}>
        <Text style={props.text_style}>Musica</Text>
        <Slider
          style={props.slider_style}
          minimumValue={0}
          maximumValue={1}
          minimumTrackTintColor={props.min_tint_color}
          maximumTrackTintColor={props.max_tint_color}
          thumbTintColor={props.thumb_tint_color}
        />
      </View>
      <View style={[, props.options_style]}>
        <Text style={props.text_style}>Efeitos Sonoros</Text>
        <Slider
          style={props.slider_style}
          minimumValue={0}
          maximumValue={1}
          minimumTrackTintColor={props.min_tint_color}
          maximumTrackTintColor={props.max_tint_color}
          thumbTintColor={props.thumb_tint_color}
        />
      </View>
    </View>
  );
}
