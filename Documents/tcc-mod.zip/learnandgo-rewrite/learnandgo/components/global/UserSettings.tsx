import { Ionicons } from "@expo/vector-icons";
import { Text, TextStyle, View, ViewStyle } from "react-native";
import TouchableIcon from "./TouchableIcon";
import { useState } from "react";

interface Props {
  container_style: ViewStyle | ViewStyle[];
  title_style: TextStyle | TextStyle[];
  options_style?: ViewStyle | ViewStyle[];
  text_style: TextStyle | TextStyle[];
}

export default function UserSettings(props: Props) {
  const [name, setName] = useState("Nome");
  const [username, setUsername] = useState("Usuario");
  const [email, setEmail] = useState("Email");
  const [censored_password, setCensoredPassword] = useState("Senha");

  return (
    <View style={props.container_style}>
      <Text style={props.title_style}>Configurações de Usuário</Text>
      <View
        style={[
          { flexDirection: "row", alignItems: "center" },
          props.options_style,
        ]}
      >
        <Text style={props.text_style}>Nome: {name} </Text>
        <TouchableIcon
          icon_style={props.text_style}
          icon_name="create-outline"
          onPress={() => {}}
          onBlur={() => {}}
        />
      </View>
      <View
        style={[
          { flexDirection: "row", alignItems: "center" },
          props.options_style,
        ]}
      >
        <Text style={props.text_style}>Usuário: {username} </Text>
        <TouchableIcon
          icon_style={props.text_style}
          icon_name="create-outline"
          onPress={() => {}}
          onBlur={() => {}}
        />
      </View>
      <View
        style={[
          { flexDirection: "row", alignItems: "center" },
          props.options_style,
        ]}
      >
        <Text style={props.text_style}>Email: {email} </Text>
        <TouchableIcon
          icon_style={props.text_style}
          icon_name="create-outline"
          onPress={() => {}}
          onBlur={() => {}}
        />
      </View>
      <View
        style={[
          { flexDirection: "row", alignItems: "center" },
          props.options_style,
        ]}
      >
        <Text style={props.text_style}>Senha: {censored_password} </Text>
        <TouchableIcon
          icon_style={props.text_style}
          icon_name="create-outline"
          onPress={() => {}}
          onBlur={() => {}}
        />
      </View>
    </View>
  );
}
