import { colors } from "@/constants/colors";
import { Ionicons } from "@expo/vector-icons";
import { Icon } from "@expo/vector-icons/build/createIconSet";
import { usePathname } from "expo-router";
import { Href, Link } from "expo-router";
import { StyleSheet, View } from "react-native";

type iconType = keyof typeof Ionicons.glyphMap;
interface Props {
  route: string;
  icon_name: iconType | string;
  color: string;
  icons_count: number;
}

export default function FloatingBarIcon(props: Props) {
  const inner_icon_style = StyleSheet.create({
    size: {
      width: `${100 / props.icons_count}%`,
      height: "100%",
      alignItems: "center",
      textAlign: "center",
      textAlignVertical: "center",
    },
  });

  return (
    <Link
      href={("/(tabs)/" + props.route) as Href}
      style={inner_icon_style.size}
    >
      <Ionicons
        name={props.icon_name as iconType}
        size={28}
        color={props.color}
      />
    </Link>
  );
}
