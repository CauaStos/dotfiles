import { ImageBackground } from "react-native";
import type React from "react";
import { View, Text } from "react-native-animatable";
import { styles } from "@/constants/style";
import { useState } from "react";

interface PropsImage {
  imgPlate: string;
  plate1: string;
  plate2: string;
  plate3: string;
}

const GamePlate = (props: PropsImage) => {
    
  return (
    <ImageBackground
      source={{ uri: props.imgPlate }}
      style={styles.placa_game}
      resizeMode="cover"
    >
      {/* {{backgroundColor: props.plate1==='a'?'red':'blue'}} */}
      <View style={styles.box_hits} >
        <View style={[styles.game_hits, { backgroundColor: props.plate1 }]}>
        </View>

        <View style={[styles.game_hits, { backgroundColor: props.plate2 }]}>
        </View>

        <View style={[styles.game_hits, { backgroundColor: props.plate3 }]}>
        </View>
      </View>
    </ImageBackground>
  );
};

export default GamePlate;
