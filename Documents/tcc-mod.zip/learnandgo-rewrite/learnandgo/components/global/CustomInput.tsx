import { StyleProp, TextInput, TextStyle } from "react-native";

interface Props {
  state_variable: boolean;
  state_function: Function;
  placeholder: string;
  placeholder_color: string;
  style: StyleProp<TextStyle>;
  style_on_focus: StyleProp<TextStyle>;
  input_state: (text: string) => void;
}

export default function CustomInput(props: Props) {
  return (
    <TextInput
      onChangeText={props.input_state}
      onFocus={() => {
        props.state_function(true);
      }}
      onBlur={() => {
        props.state_function(false);
      }}
      style={
        props.state_variable ? [props.style, props.style_on_focus] : props.style
      }
      placeholder={props.placeholder}
      placeholderTextColor={props.placeholder_color}
    />
  );
}
