import { ImageBackground } from "react-native";
import type React from "react";
import { View } from "react-native-animatable";
import { styles } from "@/constants/style";

interface PropsImage {
  imgFundo: string;
  setStateQuestion?: string;
  children: React.ReactNode;
}

const GamelImg: React.FC<PropsImage> = ({ imgFundo, children }) => {
  return (
    <ImageBackground
      source={{ uri: imgFundo }}
      style={styles.game_img}
      resizeMode="cover"
    >
      {children}
    </ImageBackground>
  );
};

export default GamelImg;
