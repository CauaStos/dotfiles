import {
  View,
  TouchableWithoutFeedback,
  Alert,
} from "react-native";
import type React from "react";
import { styles } from "@/constants/style";

interface Props {
  isCorrect: boolean;
  children: React.ReactNode;
  functionQuestion: React.Dispatch<React.SetStateAction<number>>;
  valueQuestion: number;
  map: string;
  userId: string;
  setPlate1: React.Dispatch<React.SetStateAction<string>>;
  setPlate2: React.Dispatch<React.SetStateAction<string>>;
  setPlate3: React.Dispatch<React.SetStateAction<string>>;
  hits: number;
  setHits: React.Dispatch<React.SetStateAction<number>>;
  setFinal: React.Dispatch<React.SetStateAction<boolean>>;
}

const BoxOfAeswer: React.FC<Props> = ({
  setPlate1,
  setPlate2,
  setPlate3,
  valueQuestion,
  functionQuestion,
  isCorrect,
  children,
  hits,
  setHits,
  setFinal,
}) => {
  const algumaFuncao = () => {
    Alert.alert(isCorrect ? "Resposta correta" : "Resposta errada", "", [
      {
        text: "OK",
        onPress: () => {
          isCorrect ? setHits(hits + 1) : null;
          switch (valueQuestion) {
            case 0:
              setPlate1(isCorrect ? "green" : "red");
              break;
            case 1:
              setPlate2(isCorrect ? "green" : "red");
              break;
            case 2:
              setPlate3(isCorrect ? "green" : "red");
              break;
          }
          if (valueQuestion === 2) {
            return setFinal(true);
          }
          functionQuestion(valueQuestion + 1);
        },
      },
    ]);
    return;
  };

  return (
    <TouchableWithoutFeedback onPress={algumaFuncao} style={styles.aeswer_box}>
      <View style={styles.aeswer_box}>
        <View>{children}</View>
      </View>
    </TouchableWithoutFeedback>
  );
};

export default BoxOfAeswer;
