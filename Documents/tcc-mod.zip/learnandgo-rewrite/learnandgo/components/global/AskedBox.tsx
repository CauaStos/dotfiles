import { ImageBackground } from "react-native";
import type React from "react";
import { View } from "react-native-animatable";
import { styles } from "@/constants/style";

interface Props {
  children: React.ReactNode;
}

const AskedBox: React.FC<Props> = ({ children }) => {
  const background = require('@/assets/images/asked-box.jpg');
  return (
    <ImageBackground source={background} style={styles.asked_box}>
      <View>{children}</View>
    </ImageBackground>
  );
};

export default AskedBox;