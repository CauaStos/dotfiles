import * as Animatable from "react-native-animatable";
import { colors } from "@/constants/colors";
import { font, styles } from "@/constants/style";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import {
  Button,
  Dimensions,
  Modal,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Icon } from "@expo/vector-icons/build/createIconSet";

type iconType = keyof typeof Ionicons.glyphMap;

interface Props {
  popup_message: string;
  popup_state: boolean;
  popup_state_function: (a: boolean) => void;
}

const fade_in = {
  0: {
    opacity: 0,
  },
  0.1: {
    opacity: 0.85,
  },
  1: {
    opacity: 1,
  },
};

export default function PopUp(props: Props) {
  const icon_size = Dimensions.get("screen").width * 0.08;
  const title_size = Dimensions.get("screen").width * 0.04;
  return (
    <View style={styles.popup}>
      <Animatable.View
        animation={fade_in}
        style={styles.popup_wrapper}
        delay={1}
        easing="ease-in-out"
      >
        <TouchableOpacity
          activeOpacity={0.8}
          style={[styles.popup_dismiss]}
          onPress={() => {
            props.popup_state_function(!props.popup_state);
          }}
        >
          <Text style={[font.input, font.text_accent]}>
            <Ionicons name="close-circle-outline" style={font.title} />
          </Text>
        </TouchableOpacity>

        <View style={[styles.popup_title]}>
          <Ionicons
            name="warning-outline"
            style={[styles.popup_icon]}
            size={icon_size}
          />
          <Text
            style={[
              styles.popup_title_color,
              { fontSize: title_size },
              font.body,
            ]}
          >
            {props.popup_message}
          </Text>
        </View>
      </Animatable.View>
    </View>
  );
}
