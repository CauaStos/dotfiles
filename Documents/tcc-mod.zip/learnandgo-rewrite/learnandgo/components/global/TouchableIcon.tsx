import { Ionicons } from "@expo/vector-icons";
import { TextStyle, TouchableHighlight, ViewStyle } from "react-native";

type iconType = keyof typeof Ionicons.glyphMap;

interface Props {
  icon_name: iconType;
  icon_style?: TextStyle | ViewStyle[];
  onPress: () => void;
  onBlur: () => void;
}

export default function TouchableIcon(props: Props) {
  return (
    <TouchableHighlight onPress={props.onPress} onBlur={props.onBlur}>
      <Ionicons name={props.icon_name} style={props.icon_style} />
    </TouchableHighlight>
  );
}
