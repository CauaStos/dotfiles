import { colors } from "@/constants/colors";
import { Text, View } from "react-native";
import FloatingBarIcon from "./FloatingBarIcon";
import { BlurView } from "expo-blur";
import { styles } from "@/constants/style";
import React, { useState } from "react";
import { usePathname } from "expo-router";

export default function FloatingBar({}) {
  // tabBarActiveTintColor: colors.accent,
  // tabBarInactiveTintColor: colors.iconNavigationBar,
  //
  let icons = [
    {
      route: "Map",
      icon_name: "map-outline",
    },
    {
      route: "Level",
      icon_name: "play-outline",
    },
    {
      route: "Settings",
      icon_name: "settings-outline",
    },
  ];

  const [selected_icon, setSelectedIcon] = useState(0);
  return (
    <BlurView
      style={styles.floating_bar}
      experimentalBlurMethod="dimezisBlurView"
      tint="systemUltraThinMaterialLight"
      intensity={90}
    >
      {icons.map((icon, index) => {
        return (
          <FloatingBarIcon
            key={index}
            route={icon.route}
            icon_name={icon.icon_name}
            color={
              usePathname().replace("/", "") == icon.route
                ? colors.accent
                : colors.iconNavigationBar
            }
            icons_count={icons.length}
          />
        );
      })}
    </BlurView>
  );
}
