import { TouchableWithoutFeedback, View, Image, Alert } from "react-native";
import { BlurView } from "expo-blur";
import { styles } from "@/constants/style";
import Entypo from "@expo/vector-icons/Entypo";
import { router } from "expo-router";
import { memo } from "react";
import { ImageFilter } from 'react-native-image-filter-kit';

interface Props {
  unLocked: boolean;
  portalCode: string;
  mapCode: string;
  portalImage: string;
  mapOrder: number;
  levelOrder: number;
  map: string;
  userId: string;
  completed: boolean;
}

const PortalComp = (props: Props) => {
  const translatex = [
    [
      { transform: [{ translateX: 20 }] },
      { transform: [{ translateX: 40 }] },
      { transform: [{ translateX: -40 }] },
      { transform: [{ translateX: -80 }] },
      { transform: [{ translateX: -120 }] },
    ],
    [
      { transform: [{ translateX: 80 }, { translateY: 0 }] },
      { transform: [{ translateX: 40 }, { translateY: 0 }] },
      { transform: [{ translateX: 10 }, { translateY: 0 }] },
      { transform: [{ translateX: 30 }, { translateY: 0 }] },
      { transform: [{ translateX: 50 }, { translateY: 0 }] },
    ],
    [
      { transform: [{ translateX: 80 }, { translateY: 15 }] },
      { transform: [{ translateX: -70 }, { translateY: 40 }] },
      { transform: [{ translateX: 60 }, { translateY: 100 }] },
      { transform: [{ translateX: -30 }, { translateY: 120 }] },
      { transform: [{ translateX: 0 }, { translateY: 120 }] },
    ],
    [
      { transform: [{ translateX: 0 }] },
      { transform: [{ translateX: 0 }] },
      { transform: [{ translateX: 0 }] },
      { transform: [{ translateX: 0 }] },
      { transform: [{ translateX: 0 }] },
    ],
    [
      { transform: [{ translateX: 40 }, { translateY: 0 }] },
      { transform: [{ translateX: 0 }, { translateY: 0 }] },
      { transform: [{ translateX: 70 }, { translateY: 20 }] },
      { transform: [{ translateX: 20 }, { translateY: 10 }] },
      { transform: [{ translateX: -50 }, { translateY: 0 }] },
    ],
  ];

  const mapOrder = props.mapOrder < translatex.length ? props.mapOrder : 0;
  const levelOrder =
    props.levelOrder < translatex[mapOrder].length ? props.levelOrder : 0;

  const transformStyle = translatex[mapOrder][levelOrder];

  const goToLevel = () => {
    if (!props.unLocked) {
      Alert.alert("Fase Bloqueada", "", [
        { text: "Cancel", style: "cancel" },
        { text: "OK" },
      ]);
      return;
    }
    Alert.alert("Deseja fazer essa fase?", "", [
      { text: "Cancel", style: "cancel" },
      {
        text: "OK",
        onPress: () =>
          router.push({
            pathname: "/Game",
            params: {
              levelId: props.portalCode,
              map: props.map,
              userId: props.userId,
            },
          }),
      },
    ]);
  };

  return (
    <View style={[styles.div_box_portal]}>
      <TouchableWithoutFeedback onPress={goToLevel}>
        <View>
          <Image
            source={props.completed?require('@/assets/images/portal-default.png'):{ uri: props.portalImage }}
            style={[
              styles.portalImage,
              transformStyle,
            ]}
          />
          {!props.unLocked && (
            <BlurView
              experimentalBlurMethod="dimezisBlurView"
              intensity={60}
              style={[styles.gray_scale_portal, transformStyle]}
              tint="dark"
            >
              <Entypo
                name="lock"
                size={70}
                color="white"
                style={{ opacity: 1 }}
              />
            </BlurView>
          )}
        </View>
      </TouchableWithoutFeedback>
    </View>
  );
};

export default memo(PortalComp, (prevProps, nextProps) => {
  return (
    prevProps.unLocked === nextProps.unLocked &&
    prevProps.portalCode === nextProps.portalCode &&
    prevProps.mapCode === nextProps.mapCode &&
    prevProps.portalImage === nextProps.portalImage &&
    prevProps.mapOrder === nextProps.mapOrder &&
    prevProps.levelOrder === nextProps.levelOrder
  );
});
